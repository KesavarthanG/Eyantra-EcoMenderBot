
/*
* EcoMender Bot (EB): Task 2B Path Planner
*
* This program computes the valid path from the start point to the end point.
* Make sure you don't change anything outside the "Add your code here" section.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#define V 32

#ifdef __linux__ // for host pc

    #include <stdio.h>

    void _put_byte(char c) { putchar(c); }

    void _put_str(char *str) {
        while (*str) {
            _put_byte(*str++);
        }
    }

    void print_output(uint8_t num) {
        if (num == 0) {
            putchar('0'); // if the number is 0, directly print '0'
            _put_byte('\n');
            return;
        }

        if (num < 0) {
            putchar('-'); // print the negative sign for negative numbers
            num = -num;   // make the number positive for easier processing
        }

        // convert the integer to a string
        char buffer[20]; // assuming a 32-bit integer, the maximum number of digits is 10 (plus sign and null terminator)
        uint8_t index = 0;

        while (num > 0) {
            buffer[index++] = '0' + num % 10; // convert the last digit to its character representation
            num /= 10;                        // move to the next digit
        }
        // print the characters in reverse order (from right to left)
        while (index > 0) { putchar(buffer[--index]); }
        _put_byte('\n');
    }

    void _put_value(uint8_t val) { print_output(val); }

#else  // for the test device

    void _put_value(uint8_t val) { }
    void _put_str(char *str) { }

#endif

// main function
int main(int argc, char const *argv[]) {

    #ifdef __linux__

        const uint8_t START_POINT   = atoi(argv[1]);
        const uint8_t END_POINT     = atoi(argv[2]);
        uint8_t NODE_POINT          = 0;
        uint8_t CPU_DONE            = 0;
  

    #else
        // Address value of variables for RISC-V Implementation
        #define START_POINT         (* (volatile uint8_t * ) 0x02000000)
        #define END_POINT           (* (volatile uint8_t * ) 0x02000004)
        #define NODE_POINT          (* (volatile uint8_t * ) 0x02000008)
        #define CPU_DONE            (* (volatile uint8_t * ) 0x0200000c)

    #endif

    // array to store the planned path
    

    /* Functions Usage

    instead of using printf() function for debugging,
    use the below function calls to print a number, string or a newline

    for newline: _put_byte('\n');
    for string:  _put_str("your string here");
    for number:  _put_value(your_number_here);

    Examples:
            _put_value(START_POINT);
            _put_value(END_POINT);
            _put_str("Hello World!");
            _put_byte('\n');
    */

    // ############# Add your code here #############
    // prefer declaring variable like this
    #ifdef __linux__
    uint8_t path_planned[32];
    // index to keep track of the path_planned array
    uint8_t idx = 0;
    uint32_t visited=0;
    uint8_t dist[V];         
    uint8_t parent[V];
    uint8_t u;
    uint8_t p = END_POINT;
     uint32_t graph[V] ;   
     uint8_t minimum_dist;
        

    #else
        #define START_POINT         (* (volatile uint8_t * ) 0x02000000)
         #define END_POINT           (* (volatile uint8_t * ) 0x02000004)
        #define NODE_POINT          (* (volatile uint8_t * ) 0x02000008)
         #define CPU_DONE            (* (volatile uint8_t * ) 0x0200000c)
         #define graph   (( uint32_t * ) 0x02000010)
      #define visited  (* (volatile uint32_t * ) 0x02000090)
       #define u  (* (volatile uint8_t * ) 0x02000094) //00
      #define p  (* (volatile uint8_t * ) 0x02000095)//01
      #define minimum_dist  (* (volatile uint8_t * ) 0x02000096)//10
      #define idx  (* (volatile uint8_t * ) 0x02000097)//11
      #define dist  ( (volatile uint8_t * ) 0x02000098)
      #define parent  ( (volatile uint8_t * ) 0x020000B8)
    #define path_planned  ( (volatile uint8_t*)0x020000D8)
    #endif
    visited =0;
    p = END_POINT;
    idx=0;
     graph[0] = 0b00000000000000000000010001000010;
            graph[1] = 0b00000000000000000000100000000101;
            graph[2] = 0b00000000000000000000000000111010;
            graph[3] = 0b00000000000000000000000000000100;
            graph[4] = 0b00000000000000000000000000000100;
            graph[5] = 0b00000000000000000000000000000100;

            graph[6] = 0b00000000000000000000001110000001;
            graph[7] = 0b00000000000000000000000001000000;
            graph[8] = 0b00000000000000000000000001000000;

            graph[9] = 0b00000000000000000000000001000000;
            graph[10] = 0b00000101000000000000100000000001;
            graph[11] = 0b00000000000010000001010000000010;
            
            graph[12] = 0b00000000000000000110100000000000;

            graph[13] = 0b00000000000000000001000000000000;
            graph[14] = 0b00000000000000011001000000000000;
            graph[15] = 0b00000000000000000100000000000000;

            graph[16] = 0b00000000000001100100000000000000;
            graph[17] = 0b00000000000000010000000000000000;
            graph[18] = 0b00000000001010010000000000000000;
             graph[19] = 0b00000000000101000000100000000000;
            graph[20] = 0b00000000000010000000000000000000;
            graph[21] = 0b00000000110001000000000000000000;

            graph[22] = 0b00000000001000000000000000000000;
            graph[23] = 0b01000001001000000000000000000000;
            graph[24] = 0b00000010100000000000010000000000;
            
            graph[25] = 0b00000001000000000000000000000000;
            graph[26] = 0b00011000000000000000010000000000;
            graph[27] = 0b00000100000000000000000000000000;
            graph[28] = 0b01100100000000000000000000000000;
            graph[29] = 0b00010000000000000000000000000000;
            graph[30] = 0b10010000100000000000000000000000;
            graph[31] = 0b01000000000000000000000000000000;

    for (int i = 0; i < V; i++) {
            dist[i] = UINT8_MAX;
            parent[i] = 32;
        }
    
    dist[START_POINT] = 0;

        for(int i=0; i<V; i++){
         minimum_dist = UINT8_MAX;
         u = V;

            for (int j = 0; j < V; j++) {
                if (!(visited & 1<<j) && (dist[j] < minimum_dist)) {
                    u=j;
                    minimum_dist=dist[u];

                }
            }
        if(u==V){break;}
        visited |= (1<<u);

        for (int v = 0; v < V; v++) {
            
                if (((graph[u] & (1 << v)) != 0) && (!(visited & 1<<v)) && (dist[u] + 1 < dist[v])) {
                    dist[v] = dist[u] + 1;
                    parent[v] = u;
                }
            }
        }

    
            
           
            while (p != 32) {
                path_planned[idx]=p;
                p = parent[p];
                idx = idx+1;
            }

            
    // ##############################################

    // the node values are written into data memory sequentially.
    for (int i = idx-1; i >= 0; i--) {
        NODE_POINT = path_planned[i];
    }
    // Path Planning Computation Done Flag
    CPU_DONE = 1;

    #ifdef __linux__    // for host pc

        _put_str("######### Planned Path #########\n");
        for (int i = 0; i < idx; ++i) {
            _put_value(path_planned[i]);
        }
        _put_str("################################\n");

    #endif

    return 0;
}

